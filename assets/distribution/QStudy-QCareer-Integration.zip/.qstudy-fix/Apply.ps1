﻿param([string]$Root = '', [ValidateSet('local', 'lan', 'internet')][string]$Mode, [switch]$NoPause, [switch]$Library)
# Distributed as .qstudy-fix/Apply.ps1. Source-only update: never import a ZIP or copy private data.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Resolve-QCareerFixPath([string]$Base, [string]$Relative = '') {
    $basePath = [IO.Path]::GetFullPath($Base).TrimEnd('\', '/')
    if ($Relative -match '(^|[/\\])\.\.([/\\]|$)|:|[\x00-\x1f]' -or [IO.Path]::IsPathRooted($Relative)) { throw 'Недопустимый путь в пакете исправления.' }
    $candidate = if ($Relative) { [IO.Path]::GetFullPath((Join-Path $basePath $Relative)) } else { $basePath }
    if ($candidate -cne $basePath -and -not $candidate.StartsWith($basePath + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Путь исправления выходит за пределы проекта.' }
    $current = $candidate
    while ($current.Length -ge $basePath.Length) {
        if ((Test-Path -LiteralPath $current) -and ((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Ссылки и junction в путях исправления запрещены.' }
        if ([string]::Equals($current, $basePath, [StringComparison]::OrdinalIgnoreCase)) { break }
        $current = Split-Path -Parent $current
    }
    return $candidate
}

function Get-QCareerFixFiles([string]$Root, [string]$Package) {
    $manifestPath = Resolve-QCareerFixPath $Package 'manifest.json'
    $manifest = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    if ($manifest.version -ne 1 -or $manifest.id -cnotmatch '^[a-z0-9][a-z0-9-]{1,70}$' -or $manifest.target_mode -cnotin @('local', 'lan', 'internet')) { throw 'Неизвестный формат пакета исправления.' }
    # Keep the preserving updater restricted to the exact reviewed QControl ecosystem integration and existing QBall source payload.
    $allowed = @(
        'frontend/next.config.ts',
        'frontend/package.json',
        'frontend/package-lock.json',
        'frontend/tsconfig.json',
        'frontend/app/api/[...path]/route.ts',
        'frontend/app/qball/qball.css',
        'frontend/components/lumaball/brand.tsx',
        'frontend/components/lumaball/context.tsx',
        'frontend/components/lumaball/admin-panel.tsx',
        'frontend/components/lumaball/game-room.module.css',
        'frontend/components/lumaball/game-room.tsx',
        'frontend/components/lumaball/lobby.tsx',
        'frontend/components/lumaball/map-settings.tsx',
        'frontend/components/lumaball/map-settings.module.css',
        'frontend/components/lumaball/room-settings.tsx',
        'frontend/components/lumaball/original-lobby.css',
        'frontend/components/lumaball/shell.tsx',
        'frontend/lib/lumaball/engine.ts',
        'frontend/lib/lumaball/maps.ts',
        'frontend/lib/lumaball/types.ts',
        'frontend/types/lumaball.ts',
        'frontend/lib/lumaball/room-state.ts',
        'frontend/lib/lumaball/render.ts',
        'frontend/lib/lumaball/snapshot-interpolator.ts',
        'frontend/lib/lumaball-snapshots.test.mjs',
        'frontend/lib/lumaball-render.test.mjs',
        'frontend/lib/lumaball.test.mjs',
        'frontend/lib/lumaball-maps.test.mjs',
        'frontend/lib/lumaball-parity.test.mjs',
        'frontend/lib/lumaball-room-state.test.mjs',
        'frontend/lib/fixtures/lumaball-original/provenance.json',
        'frontend/lib/fixtures/lumaball-original/utils-game.ts.txt',
        'frontend/lib/fixtures/lumaball-original/utils-player.ts.txt',
        'frontend/lib/fixtures/lumaball-original/utils-map.ts.txt',
        'frontend/lib/fixtures/lumaball-original/utils-config_game.ts.txt',
        'frontend/lib/fixtures/lumaball-original/utils-timer.ts.txt',
        'frontend/lib/fixtures/lumaball-original/utils-utils.ts.txt',
        'frontend/lib/fixtures/lumaball-original/types-player.ts.txt',
        'frontend/lib/game-csp.mjs',
        'frontend/lib/game-csp.test.mjs',
        'frontend/lib/lumaball/session-queue.ts',
        'frontend/lib/lumaball-session.test.mjs',
        'frontend/lib/native-server.integration.mjs',
        'frontend/server.mjs',
        'scripts/launcher/data.py',
        'scripts/tests/qball_physics_fixture.mjs',
        'scripts/tests/lumaball_stack.py',
        'backend/app/lumaball_room_models.py',
        'backend/app/main.py',
        'backend/app/routers/lumaball_rooms.py',
        'backend/app/services/lumaball_identity.py',
        'backend/app/services/lumaball_rooms.py',
        'backend/app/services/lumaball_realtime.py',
        'backend/tests/test_lumaball_identity.py',
        'backend/tests/test_lumaball_realtime.py',
        'backend/tests/test_lumaball_relay_performance.py',
        'backend/tests/test_lumaball_rooms.py',
        'README.md',
        'docs/qcareer-api.md',
        'docs/qcareer.md',
        'docs/accounts.md',
        'backend/app/routers/auth_routes.py',
        'backend/app/routers/academic.py',
        'backend/tests/test_registration_groups.py',
        'backend/tests/test_security.py',
        'backend/tests/smoke_bff.py',
        'frontend/components/auth-form.tsx',
        'frontend/components/identity-shell.tsx',
        'frontend/components/identity.module.css',
        'frontend/lib/identity-brand.ts',
        'frontend/public/brand/qid-placeholder.svg',
        'frontend/components/recovery-form.tsx',
        'frontend/app/login/page.tsx',
        'frontend/app/register/page.tsx',
        'frontend/app/forgot-password/page.tsx',
        'frontend/app/reset-password/page.tsx',
        'docs/host-update.md',
        'frontend/app/dashboard/modules/page.tsx',
        'frontend/app/dashboard/syllabi/page.tsx',
        'frontend/app/dashboard/profile/page.tsx',
        'backend/app/career_models.py',
        'backend/app/routers/career.py',
        'backend/app/services/career.py',
        'backend/app/routers/branding.py',
        'backend/app/services/branding.py',
        'backend/tests/test_branding.py',
        'backend/tests/test_career.py',
        'frontend/app/dashboard/admin/page.tsx',
        'frontend/app/dashboard/layout.tsx',
        'frontend/app/dashboard/tests/page.tsx',
        'frontend/app/design.css',
        'frontend/app/developers/page.tsx',
        'frontend/app/page.tsx',
        'frontend/components/academic.tsx',
        'frontend/components/branding-provider.tsx',
        'frontend/lib/auth-return.test.mjs',
        'frontend/lib/auth-return.ts',
        'frontend/lib/auth.tsx',
        'frontend/lib/assessment-link.test.mjs',
        'frontend/lib/assessment-link.ts',
        'frontend/lib/career.test.mjs',
        'frontend/lib/career.ts',
        'frontend/public/brand/qcareer-placeholder.svg',
        'frontend/public/brand/qforcelogo_qcareer.png',
        'assets/brand/source/qforcelogo_qcareer.png',
        'frontend/types/career.ts',
        'scripts/tests/career_stack.py',
        'frontend/app/qcareer/layout.tsx',
        'frontend/app/qcareer/page.tsx',
        'frontend/app/qcareer/workspace/page.tsx',
        'frontend/app/dashboard/admin/career/page.tsx',
        'frontend/components/career/workspace.tsx',
        'frontend/components/career/shell.tsx',
        'frontend/components/career/nav-link.tsx',
        'frontend/components/career/nav-link.module.css',
        'frontend/components/career/context.tsx',
        'frontend/components/career/career.module.css',
        'frontend/components/career/brand.tsx',
        'frontend/components/career/admin.module.css',
        'frontend/components/career/admin-panel.tsx',
        'frontend/app/qcontrol/layout.tsx',
        'frontend/app/qcontrol/page.tsx',
        'frontend/app/qcontrol/accounts/page.tsx',
        'frontend/app/qcontrol/branding/page.tsx',
        'frontend/app/qcontrol/operations/page.tsx',
        'frontend/app/qcontrol/qball/page.tsx',
        'frontend/app/qcontrol/qcareer/page.tsx',
        'frontend/app/qcontrol/qstudy/page.tsx',
        'frontend/app/qcontrol/qstudy/study.module.css',
        'frontend/app/qcontrol/system/page.tsx',
        'frontend/app/qcontrol/qstudy/groups/page.tsx',
        'frontend/app/qcontrol/qstudy/modules/page.tsx',
        'frontend/app/qcontrol/qstudy/subjects/page.tsx',
        'frontend/app/qcontrol/qstudy/syllabi/page.tsx',
        'frontend/app/qcontrol/qstudy/groups/[groupId]/page.tsx',
        'frontend/app/qcontrol/qstudy/groups/[groupId]/courses/[courseId]/page.tsx',
        'frontend/components/control/accounts.tsx',
        'frontend/components/control/control.module.css',
        'frontend/components/control/ecosystem-branding-admin.tsx',
        'frontend/components/control/operations.module.css',
        'frontend/components/control/OperationsPanel.tsx',
        'frontend/components/control/ServerSettingsForm.tsx',
        'frontend/components/control/shell.tsx',
        'frontend/components/control/system.module.css',
        'frontend/components/control/SystemPanel.tsx',
        'frontend/lib/control-session.ts',
        'frontend/lib/ecosystem-branding.ts',
        'frontend/lib/ecosystem-branding.test.mjs',
        'frontend/lib/study-management.ts',
        'frontend/lib/study-routing.ts',
        'frontend/lib/study-routing.test.mjs',
        'frontend/components/ecosystem-branding.tsx',
        'frontend/components/branding-admin.tsx',
        'assets/brand/source/qforcelogo_q-id.png',
        'assets/brand/source/qforcelogo_qcontrol.png',
        'frontend/public/brand/qforcelogo_q-id.png',
        'frontend/public/brand/qforcelogo_qcontrol.png',
        'docs/qcontrol.md',
        'frontend/app/dashboard/admin/qball/page.tsx',
        'frontend/app/dashboard/groups/[groupId]/courses/[courseId]/page.tsx',
        'frontend/app/dashboard/groups/[groupId]/page.tsx',
        'frontend/app/dashboard/groups/page.tsx',
        'frontend/app/dashboard/subjects/page.tsx',
        'frontend/components/syllabus-document.tsx',
        'frontend/components/work-card.tsx',
        'frontend/lib/branding.ts',
        'backend/app/qtests_models.py',
        'backend/app/routers/admin.py',
        'backend/app/routers/qtests.py',
        'backend/app/services/qtests_import.py',
        'backend/tests/test_qtests.py',
        'backend/tests/test_qtests_import.py',
        'docs/qtests.md',
        'frontend/app/dashboard/jobs/page.tsx',
        'frontend/app/qcontrol/qtests/page.tsx',
        'frontend/app/qtests/attempts/[id]/page.tsx',
        'frontend/app/qtests/banks/[id]/page.tsx',
        'frontend/app/qtests/layout.tsx',
        'frontend/app/qtests/library/page.tsx',
        'frontend/app/qtests/page.tsx',
        'frontend/components/qtests-brand.tsx',
        'frontend/components/qtests/attempt.tsx',
        'frontend/components/qtests/bank.tsx',
        'frontend/components/qtests/library.tsx',
        'frontend/components/qtests/qtests.module.css',
        'frontend/components/qtests/question-editor.tsx',
        'frontend/components/qtests/shell.tsx',
        'frontend/components/qtests/workspace-frame.tsx',
        'frontend/lib/qtests.ts',
        'frontend/public/brand/qtests-prototype.svg',
        'scripts/tests/qtests_stack.py',
        'backend/tests/test_qtests_lessons.py',
        'frontend/components/control/qtests-lessons.tsx'
    )
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $files = @(); $size = 0
    foreach ($entry in @($manifest.files)) {
        $relative = [string]$entry.path
        if ($relative.Contains('\') -or $relative.Contains('//') -or $relative -match '(^|/)(\.|\.env[^/]*|\.next|node_modules|uploads|\.git|\.local)(/|$)' -or
            $allowed -cnotcontains $relative -or
            [string]$entry.sha256 -cnotmatch '^[a-f0-9]{64}$' -or -not $seen.Add($relative)) { throw 'Пакет содержит запрещённый или повторный путь. Допускаются только проверенные исходники QControl/Q-ID/QCareer/QStudy, закреплённые зависимости и совместимые изменения QBall.' }
        $source = Resolve-QCareerFixPath $Package ('payload/' + $relative)
        $target = Resolve-QCareerFixPath $Root $relative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'В пакете отсутствует исходник.' }
        $length = (Get-Item -LiteralPath $source).Length; $size += $length
        if ($length -gt 4MB -or $size -gt 32MB -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.sha256) { throw 'Проверка SHA256 или размера исходников не пройдена.' }
        if ((Test-Path -LiteralPath $target) -and -not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'На месте исходника находится каталог.' }
        $files += [pscustomobject]@{ path = $relative; source = $source; target = $target; sha256 = $entry.sha256 }
    }
    if ($files.Count -lt 1 -or $files.Count -gt 256) { throw 'Пакет должен содержать от 1 до 256 исходников.' }
    return [pscustomobject]@{ manifest = $manifest; files = $files }
}

function Assert-QCareerNoLegacyRuntime([string]$Root) {
    $path = Resolve-QCareerFixPath $Root '.local/processes.json'
    if (-not (Test-Path -LiteralPath $path)) { return }
    $legacy = Read-QStudyInstallJson $path
    if ($null -eq $legacy -or $legacy.version -notin @(1, 2) -or -not [string]::Equals($legacy.workspace, $Root, [StringComparison]::OrdinalIgnoreCase) -or ($legacy.version -eq 2 -and $legacy.computer -cne (Get-QStudyComputerFingerprint))) { throw 'Прежнее состояние запуска не подтверждено. Исходники не заменялись.' }
    foreach ($name in @('frontend', 'backend')) {
        if ($null -ne (Get-QStudyInstallProperty $legacy $name)) { throw 'Обнаружены записи прежнего локального запуска. Остановите его штатно перед исправлением.' }
    }
}

if ($Library) { return }
$lock = $null; $backup = ''; $failed = $false; $pending = ''; $stage = 'проверка пакета'
try {
    if (-not $Root) { throw 'Укажите корень существующего QStudy.' }
    $Root = Resolve-QCareerFixPath $Root
    $package = Resolve-QCareerFixPath $Root '.qstudy-fix'
    if (-not [string]::Equals($package, $PSScriptRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Распакуйте пакет исправления прямо в существующую папку QStudy.' }
    foreach ($name in @('frontend', 'backend', 'scripts')) {
        if (-not (Test-Path -LiteralPath (Resolve-QCareerFixPath $Root $name) -PathType Container)) { throw 'В выбранной папке нет полного существующего QStudy.' }
    }
    $plan = Get-QCareerFixFiles $Root $package
    $native = Resolve-QCareerFixPath $package 'stop/scripts/launcher/Native.ps1'
    $stop = Resolve-QCareerFixPath $package 'stop/scripts/launcher/Stop-Previous.ps1'
    $start = Resolve-QCareerFixPath $Root 'scripts/Start-QStudy.ps1'
    if (-not (Test-Path -LiteralPath $stop -PathType Leaf) -or -not (Test-Path -LiteralPath $start -PathType Leaf)) { throw 'Отсутствует штатный файл остановки или запуска.' }
    . $native
    $script:QStudyRoot = $Root; $script:QStudyLocal = Join-Path $Root '.local'; $script:QStudyStateFile = Join-Path $script:QStudyLocal 'processes.json'
    $stage = 'проверка владельца и действующего запуска'
    Assert-QStudyNativeStopOwner $Root
    Assert-QCareerNoLegacyRuntime $Root
    $statePath = Resolve-QCareerFixPath $Root '.local/launcher/state.json'
    $state = Read-QStudyNativeState $Root
    if ((Test-Path -LiteralPath $statePath) -and $null -eq $state) { throw 'Состояние запуска повреждено или относится к другой установке. Процессы и исходники сохранены.' }
    if ($null -ne $state -and $state.mode -cnotin @('local', 'lan', 'internet')) { throw 'Режим прежнего запуска не подтверждён.' }
    $chosenMode = if ($Mode) { $Mode } elseif ($null -ne $state) { $state.mode } else { $plan.manifest.target_mode }
    $owned = $false
    if ($null -ne $state) {
        foreach ($name in @('supervisor', 'frontend', 'backend')) {
            $record = Get-QStudyInstallProperty $state $name
            if ($null -ne $record -and $null -ne (Get-QStudyOwnedProcess $record.identity)) { $owned = $true }
        }
    }
    $managedPath = Resolve-QCareerFixPath $Root '.local/managed/status.json'
    $managed = Read-QStudyInstallJson $managedPath
    if ($null -ne $managed -and (Get-QStudyInstallProperty $managed 'state' '') -cne 'stopped') {
        foreach ($name in @('backend', 'frontend')) {
            $childId = [int](Get-QStudyInstallProperty $managed ($name + '_pid') 0)
            if ($childId -gt 0 -and $null -ne (Get-QStudyProcess $childId)) {
                if ($null -eq $state -or $managed.root_owner -cne $Root -or $managed.instance -cne $state.instance) { throw 'Нельзя подтвердить владельца работающего сайта. Остановите его через админку.' }
                $owned = $true
            }
        }
    }
    $powershell = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
    if ($owned) {
        $stage = 'штатная остановка сайта'
        & $powershell -NoProfile -ExecutionPolicy Bypass -File $stop -Root $Root -NoPause
        if ($LASTEXITCODE -ne 0) { throw 'Штатная остановка не завершена. Исходники не заменялись.' }
    } else { Write-Host 'Подтверждённых работающих процессов штатного запуска не найдено; чужие процессы не останавливаются.' }
    $lock = Enter-QStudyLock
    Assert-QStudyNativeStopOwner $Root
    Assert-QCareerNoLegacyRuntime $Root
    $currentState = Read-QStudyNativeState $Root
    if ((Test-Path -LiteralPath $statePath) -and $null -eq $currentState) { throw 'Состояние запуска изменилось после остановки. Исходники не заменялись.' }
    if ($null -ne $currentState) {
        foreach ($name in @('supervisor', 'frontend', 'backend')) {
            $record = Get-QStudyInstallProperty $currentState $name
            if ($null -ne $record -and $null -ne (Get-QStudyOwnedProcess $record.identity)) { throw 'Сайт повторно запущен другим стартером. Исходники не заменялись; повторите исправление.' }
        }
    }
    $stage = 'резервная копия изменяемых исходников'
    $changed = @($plan.files | Where-Object { -not (Test-Path -LiteralPath $_.target) -or (Get-FileHash -LiteralPath $_.target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $_.sha256 })
    $backup = Resolve-QCareerFixPath $Root ('.local/source-updates/' + $plan.manifest.id + '-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($backup) | Out-Null; Protect-QStudyNativePath $backup
    foreach ($file in $changed) {
        $destination = Resolve-QCareerFixPath $backup $file.path
        [IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
        if (Test-Path -LiteralPath $file.target -PathType Leaf) { [IO.File]::Copy($file.target, $destination, $false) }
    }
    [IO.File]::WriteAllText((Join-Path $backup 'files.json'), (ConvertTo-Json -InputObject @($changed | ForEach-Object { $_.path })), [Text.UTF8Encoding]::new($false))
    $stage = 'замена проверенных исходников'
    foreach ($file in $changed) {
        [void](Resolve-QCareerFixPath $Root $file.path); [void](Resolve-QCareerFixPath $package ('payload/' + $file.path))
        if ((Get-FileHash -LiteralPath $file.source -Algorithm SHA256).Hash.ToLowerInvariant() -cne $file.sha256) { throw 'Пакет изменился после проверки. Сохранена копия исходников.' }
        [IO.Directory]::CreateDirectory((Split-Path -Parent $file.target)) | Out-Null
        $pending = $file.target + '.qstudy-fix-' + [Guid]::NewGuid().ToString('N') + '.tmp'
        [IO.File]::Copy($file.source, $pending, $false)
        if (Test-Path -LiteralPath $file.target -PathType Leaf) { [IO.File]::Replace($pending, $file.target, [NullString]::Value) } else { [IO.File]::Move($pending, $file.target) }
        $pending = ''
    }
    $lock.Dispose(); $lock = $null
    $stage = 'сборка и повторный запуск'
    & $powershell -NoProfile -ExecutionPolicy Bypass -File $start -Mode $chosenMode -NoBrowser -NoPause
    if ($LASTEXITCODE -ne 0) { throw 'Исходники обновлены, но штатный запуск не завершён. Исправьте указанную стартером причину и повторите Start-QStudy.' }
    Write-Host 'QControl и экосистема обновлены, штатный запуск завершён. Текущие база, аккаунты и настройки сохранены.' -ForegroundColor Green
} catch {
    $failed = $true
    Write-Host ('QControl: этап «' + $stage + '» не завершён. ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'База и .env не импортировались и не заменялись. Автоматический откат не выполнялся.'
} finally {
    if ($null -ne $lock) { $lock.Dispose() }
    if ($pending -and (Test-Path -LiteralPath $pending -PathType Leaf)) { Remove-Item -LiteralPath $pending -Force }
    if ($backup) { Write-Host ('Копия изменяемых исходников: ' + $backup) }
}
if (-not $NoPause) { [void](Read-Host 'Нажмите Enter, чтобы закрыть окно') }
if ($failed) { exit 1 }; exit 0
