@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0.qstudy-fix\Apply.ps1" -Root "%~dp0." %*
exit /b %errorlevel%
